require File.join(File.dirname(__FILE__), "scrape.rb")
STATE = "Alabama"
COUNTY = "Dothan County"
CITY = "Dothan"
	BASE="http://www.doc.state.al.us/inmresults.asp?AIS=&FirstName=&LastName="
	scrape = DFG::Scrape.new(STATE, COUNTY, CITY, BASE)
	arrest = DFG::Arrest.new()
	doc = scrape.get(BASE)
	 count=doc.css('td:nth-child(2)').size
	 for i in 1..count-1
		 name=doc.css('td:nth-child(2)')[i].text
		
        arrest.name = name
	bond=0
	desc= "Nil"
	arrest.add_charge(desc, bond)    
scrape.add(arrest)
scrape.commit()
		 
	 end
	 
	