require File.join(File.dirname(__FILE__), "scrape.rb")
STATE = "Indiana"
COUNTY = "Ft. Wayne County"
CITY = "Ft. Wayne"
BASE="http://doc-apps.in.gov/demo/wanted/Most_Wantedlist.asp?pageno=1&RecPerPage=ALL"
scrape = DFG::Scrape.new(STATE, COUNTY, CITY, BASE)
 arrest = DFG::Arrest.new()
doc= scrape.get(BASE)
 doc.css('td.ewTableRow').each {|i|
 f_name= i.css('tr')[0].css('td')[1].css('div').inner_html
 l_name= i.css('tr')[1].css('td')[1].css('div').inner_html
 name=f_name+', '+l_name
img= i.css('tr')[2].css('td')[1].css('a img').to_html.split('"')[1].split('"').first
  image=URI.encode("http://doc-apps.in.gov/demo/wanted/#{img}")
  date= i.css('tr')[14].css('td')[1].css('div').inner_html
arrest.image1 = arrest.image2=image rescue ""
	arrest.name = name rescue ""
	
	if !date.empty?
	 arrest.date = DateTime.strptime(date, "%m/%d/%Y") rescue ""
	 end
	bond=0
	descr="NIL"
	arrest.add_charge(descr, bond)    
	scrape.add(arrest)
	scrape.commit()

}
 
 

 