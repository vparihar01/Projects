require File.join(File.dirname(__FILE__), "scrape.rb")

STATE = "Indiana"
COUNTY = "Evansville  County"
CITY = "Evansville"
bond=0
BASE="http://www.in.gov/apps/indcorrection/ofs/ofs"

scrape = DFG::Scrape.new(STATE, COUNTY, CITY, BASE)
arrest = DFG::Arrest.new()
for i in "a".."z"
	
 DETAILEDURL="http://www.in.gov/apps/indcorrection/ofs/ofs?lname=&fname=#{i}&search1.x=65&search1.y=56"
 doc = scrape.get(DETAILEDURL)
 page_no=doc.css('td:nth-child(4) font').css('a').size
 pages=doc.css('td:nth-child(4) font').css('a').each {|p| 
 params=p.to_s.split('?').last.split('>').first.gsub('&amp;','&').chop
 URL1="http://www.in.gov/apps/indcorrection/ofs/ofs?#{params}"
 doc1 = scrape.get(URL1)
 size=doc1.css('td:nth-child(2) a').size
(0..size-1).each{|p|
		params1=doc1.css('a')[p].to_s.split('?').last.split('>').first.gsub('&amp;','&').chop
		URL2="http://www.in.gov/apps/indcorrection/ofs/ofs?#{params1}"
		doc2= scrape.get(URL2)
		firstname=doc2.css('tr:nth-child(1) tr:nth-child(3) td:nth-child(2)').css('font').inner_html rescue ''
		middlename=doc2.css('tr:nth-child(1) tr:nth-child(4) td:nth-child(2)').css('font').inner_html rescue ''
		lastname=doc2.css('tr:nth-child(1) tr:nth-child(5) td:nth-child(2) font').inner_html rescue ''
		name2=[middlename,firstname].join(' ').squeeze(' ')
		name=[lastname,name2].join(',').squeeze(' ')
		if (name!="")
		  arrest.name = name
		end
		descr=doc2.css('tr:nth-child(3) tr:nth-child(3) td:nth-child(2) font').inner_html rescue ''
		descr.split(',').each{|desc|
		if (desc!="")
			arrest.add_charge(desc, bond)
		end
		}
		scrape.add(arrest)
		scrape.commit()
 }
}
end